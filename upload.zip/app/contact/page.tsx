import OrderForm from '@/components/OrderForm'

export default function page() {
  return (
    <OrderForm />
  )
}
